



#include "joy.h"
#include "Comm.h"
#include "Motor.h"

//#include "Pin.h"
//#include "adc16.h"
#include "Timer.h"
//#include "UART.h"


//#include <stdio.h>
//#include <string.h>



static char joy_msg[20];

void App_Init (void)
{
	// Low level Init
	//Pin_Init();
	//ADC_Init();
	//PWM_Init();
	Timer_Init();
	//UART_Init();

	Mot_Init();
	joy_Init();
	Comm_Init();
}



void App_Run (void)
{
	Comm_Update();

	if (Comm_ReadJoyMsg(joy_msg))
	{
		joy_ParseString(joy_msg);
	}

}

