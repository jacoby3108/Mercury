/***************************************************************************//**
  @file     Comm.c
  @brief    Communication parser
  @author   Daniel Jacoby, Nicol�s Magliola
 ******************************************************************************/


/*******************************************************************************
 * INCLUDE HEADER FILES
 ******************************************************************************/

#include "Comm.h"

#include "UART.h"

#include <string.h>


/*******************************************************************************
 * CONSTANT AND MACRO DEFINITIONS USING #DEFINE
 ******************************************************************************/

#define STX 0x02
#define ETX 0x03
#define ENQ 0x05
#define ACK 0x06
#define NACK 0x15


/*******************************************************************************
 * ENUMERATIONS AND STRUCTURES AND TYPEDEFS
 ******************************************************************************/

/*******************************************************************************
 * VARIABLES WITH GLOBAL SCOPE
 ******************************************************************************/

/*******************************************************************************
 * FUNCTION PROTOTYPES FOR PRIVATE FUNCTIONS WITH FILE LEVEL SCOPE
 ******************************************************************************/

static uint8_t parse_incomming_data(char data);


/*******************************************************************************
 * ROM CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/

/*******************************************************************************
 * STATIC VARIABLES AND CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/

static char rx_msg[20];
static char tx_msg[] = {STX, 'A', 'A', ETX};

static char joy_msg[20];
static bool new_joy_msg = FALSE;

/*******************************************************************************
 *******************************************************************************
                        GLOBAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/


void Comm_Init (void)
{
	UART_Init();
}


void Comm_Update (void)
{
	char c;

	while(UART_ReadMsg(&c, 1))
	{ // New data arrived
		if (parse_incomming_data(c))
		{ // Compleate msg arrived!

			if (tx_msg[2] < 'Z')
				++(tx_msg[2]);
			else
				tx_msg[2] = 'A';

			(void) UART_WriteMsg(tx_msg, 4); //Send an answer

			strcpy(joy_msg, rx_msg); // Copy received msg
			new_joy_msg = TRUE;
		}
	}
}


uint8_t Comm_IsNewJoyMsg (void)
{
	return new_joy_msg;
}


uint8_t Comm_ReadJoyMsg (char * str)
{
	uint8_t msg_copied = FALSE;
	if (str && new_joy_msg)
	{
		strcpy(str, joy_msg);
		new_joy_msg = FALSE;
		msg_copied = TRUE;
	}
	return msg_copied;
}


/*******************************************************************************
 *******************************************************************************
                        LOCAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/


static uint8_t parse_incomming_data(char data)		// tiny FSM
{
	enum STATE {S_ILDE,S_GET_DATA};
	static enum STATE rx_state=S_ILDE;
	static int i=0;
	uint8_t message_arrived = FALSE;


	if(data==STX)
	{ // forced FSM reset
		rx_state=S_GET_DATA;
		i=0;
	}
	else if(rx_state==S_GET_DATA)
	{
		if(data==ETX)			//End of Frame
		{
			rx_state=S_ILDE;
			rx_msg[i]='\0';		//Payload Terminator
			message_arrived=TRUE;
		}
		else // valid ASCII
		{
			rx_msg[i++]=data;			//Store Payload
		}
	}

	return message_arrived;
}

