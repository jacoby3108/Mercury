/*
 * joy.c
 *
 *  Created on: 21/8/2017
 *      Author: dany
 */


/*******************************************************************************
 * INCLUDE HEADER FILES
 ******************************************************************************/

#include "joy.h"

#include <string.h>
#include <stdlib.h>

// For default actions
#include "Pin.h"
#include "Motor.h"


/*******************************************************************************
 * CONSTANT AND MACRO DEFINITIONS USING #DEFINE
 ******************************************************************************/

//#define JOY_DEBUG_ENA


/*******************************************************************************
 * ENUMERATIONS AND STRUCTURES AND TYPEDEFS
 ******************************************************************************/




/*******************************************************************************
 * VARIABLES WITH GLOBAL SCOPE
 ******************************************************************************/

/*******************************************************************************
 * FUNCTION PROTOTYPES FOR PRIVATE FUNCTIONS WITH FILE LEVEL SCOPE
 ******************************************************************************/

static void fbot0(int);
static void fbot1(int);
static void fbot2(int);
static void fbot3(int);
static void faxisDesplazamiento(int value);
static void faxisRotacion(int value);
static void faxisVelocidad(int value);

static void updateMotorsConfig(void);

/*******************************************************************************
 * ROM CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/


/*******************************************************************************
 * STATIC VARIABLES AND CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/

static joyActionFun_t joyActionList[JOY_CANT_IDS] = { // default actions, can be changed
	NULL,		// JOY_ID_AXIS_LX,
	NULL,		// JOY_ID_AXIS_LY,
	NULL,	// JOY_ID_AXIS_RX,
	faxisVelocidad,	// JOY_ID_AXIS_RY,
	faxisRotacion,		// JOY_ID_AXIS_PADX,
	faxisDesplazamiento,		// JOY_ID_AXIS_PADY,
	fbot0,		// JOY_ID_BUT_GREEN1,
	fbot1, 		// JOY_ID_BUT_RED2,
	fbot2,		// JOY_ID_BUT_BLUE3,
	fbot3,		// JOY_ID_BUT_PINK4,
	NULL,		// JOY_ID_BUT_L1,
	NULL,		// JOY_ID_BUT_R1,
	NULL,		// JOY_ID_BUT_L2,
	NULL,		// JOY_ID_BUT_R2,
	NULL,		// JOY_ID_BUT_SELECT,
	NULL,		// JOY_ID_BUT_START,
	NULL,		// JOY_ID_BUTT10,
	NULL		// JOY_ID_BUTT11,
};

static int16_t joyCtrlVal[JOY_CANT_IDS];


/*******************************************************************************
 *******************************************************************************
                        GLOBAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/

void joy_Init(void)
{
	Mot_Init();
	Pin_Init();

#ifdef JOY_DEBUG_ENA
	UART_Init();
#endif // JOY_DEBUG_ENA
}


void joy_RegisterCallbackAction(joyCtrId_t id, joyActionFun_t funPtr)
{
	if (id < JOY_CANT_IDS && funPtr != NULL)
	{
		joyActionList[id] = funPtr;
	}
}


int16_t joy_ReadCtrlVal(joyCtrId_t id)
{
	int16_t val = 0;
	if (id < JOY_CANT_IDS)
	{
		val = joyCtrlVal[id];
	}
	return val;
}

void joy_ParseString(unsigned char *ptr_joy_message)
{
	const char *delimiter=":,";
	char *pt;
	joyCtrId_t ctrlId = JOY_CANT_IDS; // invalid joyId

	unsigned char joy_control_type[2];
	int  joy_control_number;
	int joy_control_value;

	// Parse received string
	pt = strtok(ptr_joy_message, delimiter); //Control type: Axis or Button
	strcpy(joy_control_type,pt);

	pt = strtok(NULL, delimiter);	// Control Number
	joy_control_number=atoi(pt);

	pt = strtok(NULL, delimiter);	// Control Value
	joy_control_value=atoi(pt);

#ifdef JOY_DEBUG_ENA
	printf("JOYSTICK >>>>>> %s%02d: %d\n", joy_control_type, joy_control_number, joy_control_value);
#endif // JOY_DEBUG_ENA

	if(!strcmp(joy_control_type,"B"))  //Was a button?
	{
		if (joy_control_number < JOY_BUTTONS_CANT)
		{
			ctrlId = joy_control_number + JOY_ID_BUTT0;
		}
	}
	else if(!strcmp(joy_control_type,"A")) //Was an Axis?
	{
		if (joy_control_number < JOY_AXIS_CANT)
		{
			ctrlId = joy_control_number + JOY_ID_AXIS0;
		}
	}

	if (ctrlId < JOY_CANT_IDS)
	{
		joyCtrlVal[ctrlId] = joy_control_value;
		if (joyActionList[ctrlId] != NULL)
		{
			joyActionList[ctrlId](joy_control_value);
#ifdef JOY_DEBUG_ENA
			printf("JOYSTICK >>>>>> Call Action %d\n", joyId);
#endif // JOY_DEBUG_ENA
		}
	}
}

/*******************************************************************************
 *******************************************************************************
                        LOCAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/


// This code goes on Kinetis Board (this is a Test Bench)
//// Importante activar la funcion Analog en el joystick

// Button functions

static void fbot0(int value)			// Boton 1 verde
{
	 Pin_Write(PIN_LED_GREEN, value);

}

static void fbot1(int value)			// Boton 2 Rojo
{
	 Pin_Write(PIN_LED_RED, value);
}

static void fbot2(int value)			// Boton 3 Celeste
{
	 Pin_Write(PIN_LED_BLUE, value);
}

static void fbot3(int value)			// Boton 4 Rosa
{
	 Pin_Write(PIN_LED_BLUE, value);
	 Pin_Write(PIN_LED_RED, value);
}



// Axis functions

void faxisIzq(int value)
{
	Mot_WriteDutyNow(MOT_ID_IZQ, (127 - value)<<1);
}

void faxisDer(int value)
{
	Mot_WriteDutyNow(MOT_ID_DER, (127 - value)<<1);
}


/*
 value:
 	 	 0 -> full UP/IZQ
 	 	 127 -> middle point
 	 	 255 -> full DOWN/DER
 */

#define JOY_MOT_DUTY_NOMINAL	128
motDuty_t desplazamiento, direccion, velocidad;
motDuty_t dutyMotIzq, dutyMotDer;

static void faxisDesplazamiento(int value)
{
	if (value < 64)
		desplazamiento = 1;
	else if (value > 127+64)
		desplazamiento = -1;
	else
		desplazamiento = 0;

	updateMotorsConfig();
}

static void faxisRotacion(int value)
{
	if (value < 64)
		direccion = -1;
	else if (value > 127+64)
		direccion = 1;
	else
		direccion = 0;

	updateMotorsConfig();
}

static void faxisVelocidad(int value)
{
	velocidad = 127-value;

	updateMotorsConfig();
}

#define MOT_DUTY_DESPLAZAMIENTO_NOM		200
#define MOT_DUTY_ROTACION_NOM			180

// Turn right:	DUTY_MOT_IZQ > 0 and DUTY_MOT_DER < 0
// Turn left:	DUTY_MOT_DER > 0 and DUTY_MOT_IZQ < 0

static void updateMotorsConfig(void)
{
	motDuty_t desp, dir;

	desp = desplazamiento * (MOT_DUTY_DESPLAZAMIENTO_NOM + (velocidad>>1));
	dir = direccion * (MOT_DUTY_ROTACION_NOM + (velocidad>>1));
	dutyMotIzq = desp + dir;
	dutyMotDer = desp - dir;

	Mot_WriteDutyNow(MOT_ID_IZQ, dutyMotIzq);
	Mot_WriteDutyNow(MOT_ID_DER, dutyMotDer);
}
