
#ifndef SOURCES_APP_H_
#define SOURCES_APP_H_

void App_Init	(void);
void App_Run	(void);

#endif
