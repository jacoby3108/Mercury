/*
 * joy.h
 *
 *  Created on: 21/8/2017
 *      Author: Daniel Jacoby, Nicolas Magliola
 */

#ifndef SOURCES_JOY_H_
#define SOURCES_JOY_H_


/*******************************************************************************
 * INCLUDE HEADER FILES
 ******************************************************************************/

#include "common.h"


/*******************************************************************************
 * CONSTANT AND MACRO DEFINITIONS USING #DEFINE
 ******************************************************************************/

/*******************************************************************************
 * ENUMERATIONS AND STRUCTURES AND TYPEDEFS
 ******************************************************************************/

typedef enum {
	JOY_ID_AXIS_LX,
	JOY_ID_AXIS_LY,
	JOY_ID_AXIS_RX,
	JOY_ID_AXIS_RY,
	JOY_ID_AXIS_PADX,
	JOY_ID_AXIS_PADY,
	JOY_ID_BUT_GREEN1,
	JOY_ID_BUT_RED2,
	JOY_ID_BUT_BLUE3,
	JOY_ID_BUT_PINK4,
	JOY_ID_BUT_L1,
	JOY_ID_BUT_R1,
	JOY_ID_BUT_L2,
	JOY_ID_BUT_R2,
	JOY_ID_BUT_SELECT,
	JOY_ID_BUT_START,
	JOY_ID_BUTT10,
	JOY_ID_BUTT11,

	JOY_CANT_IDS
}joyCtrId_t;

#define JOY_ID_BUTT0		JOY_ID_BUT_GREEN1
#define JOY_ID_AXIS0		JOY_ID_AXIS_LX

#define JOY_AXIS_CANT		6
#define JOY_BUTTONS_CANT	12

typedef void(*joyActionFun_t)(int value);


/*******************************************************************************
 * VARIABLE PROTOTYPES WITH GLOBAL SCOPE
 ******************************************************************************/

/*******************************************************************************
 * FUNCTION PROTOTYPES WITH GLOBAL SCOPE
 ******************************************************************************/

void joy_Init(void);
void joy_RegisterCallbackAction(joyCtrId_t id, joyActionFun_t funPtr);

void joy_ParseString(unsigned char *ptr_joy_message);
int16_t joy_ReadCtrlVal(joyCtrId_t id);


/*******************************************************************************
 ******************************************************************************/


#endif /* SOURCES_JOY_H_ */
