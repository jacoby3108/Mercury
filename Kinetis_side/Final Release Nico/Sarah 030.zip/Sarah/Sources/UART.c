/***************************************************************************//**
  @file     UART.c
  @brief    UART Driver for K64F. Non-Blocking and using FIFO feature
  @author   Nicol�s Magliola
 ******************************************************************************/

/*******************************************************************************
 * INCLUDE HEADER FILES
 ******************************************************************************/

#include "UART.h"

#include "PORT.h"
#include "Template/LDM.h"


/*******************************************************************************
 * CONSTANT AND MACRO DEFINITIONS USING #DEFINE
 ******************************************************************************/

//#define UART_FIFO_FEATURE_ENA

#define UART_HAL_DEFAULT_BAUDRATE 9600

// UART0 Configuration

#define UART_NUM			3

#if UART_NUM == 0
#define UART_BASE			UART0
#define UART_RX_FIFO_SIZE	8
#define UART_TX_FIFO_SIZE	8
#elif UART_NUM == 3
#define UART_BASE			UART3
#define UART_RX_FIFO_SIZE	1
#define UART_TX_FIFO_SIZE	1
#endif // UART_NUM == xx

// PORT definitions
#if UART_NUM == 0
#define PORT_UART			PORTB //UART0
#define UART_RX_PIN			16   //PTB16
#define UART_TX_PIN			17   //PTB17
#elif UART_NUM == 3
#define PORT_UART			PORTC //UART1
#define UART_RX_PIN			16   //PTC16
#define UART_TX_PIN			17   //PTC17
#endif // UART_NUM == xx

#define UART_PORT_CONFIG	(PCRstr) {0, 0, 0, 0, 0, 0, 0, 0, PORT_mAlt3, 0, 0, PORT_eDisabled, 0, 0, 0}


// QUEUE definitions
#define UART_RX_QUEUE_MSK			(UART_RX_QUEUE_SIZE-1)
#define UART_TX_QUEUE_MSK			(UART_TX_QUEUE_SIZE-1)

#define UART_QUEUE_INDEX_INC(i, m)	((i) = ((i)+1) & (m))


/*******************************************************************************
 * ENUMERATIONS AND STRUCTURES AND TYPEDEFS
 ******************************************************************************/

typedef struct {
	uint8_t iPut;
	uint8_t iGet;
	uint8_t count;
	uint8_t size;
	uint8_t *buffer;
} uart_queue_t;


/*******************************************************************************
 * VARIABLES WITH GLOBAL SCOPE
 ******************************************************************************/

/*******************************************************************************
 * FUNCTION PROTOTYPES FOR PRIVATE FUNCTIONS WITH FILE LEVEL SCOPE
 ******************************************************************************/

static void UART_SetBaudRate (UART_Type *uart, uint32_t baudrate);

static void UART_FlushRxFifoIntoQueue(void);
static void UART_FlushTxQueueIntoFifo(void);


/*******************************************************************************
 * ROM CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/

/*******************************************************************************
 * STATIC VARIABLES AND CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/

static char rx_buffer[UART_RX_QUEUE_SIZE];
static char tx_buffer[UART_TX_QUEUE_SIZE];

static uart_queue_t rx_queue = {0, 0, 0, UART_RX_QUEUE_SIZE, rx_buffer};
static uart_queue_t tx_queue = {0, 0, 0, UART_TX_QUEUE_SIZE, tx_buffer};



/*******************************************************************************
 *******************************************************************************
                        GLOBAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/

void UART_Init (void)
{
	static bool yaInit = FALSE;
	if (yaInit)
		return;

#if UART_NUM == 0
	SIM_SCGC4 |= SIM_SCGC4_UART0_MASK; // Enable Clock Gating for UART0
	NVIC_EnableIRQ(UART0_RX_TX_IRQn); // Enable UART0's IRQ in NVIC
#elif UART_NUM == 3
	SIM_SCGC4 |= SIM_SCGC4_UART3_MASK; // Enable Clock Gating for UART3
	NVIC_EnableIRQ(UART3_RX_TX_IRQn); // Enable UART3's IRQ in NVIC
#endif // UART_NUM == xx

	PORT_Configure2(PORT_UART, UART_TX_PIN, UART_PORT_CONFIG); //Setup PORT for TX and RX pins
	PORT_Configure2(PORT_UART, UART_RX_PIN, UART_PORT_CONFIG);

	UART_SetBaudRate(UART_BASE, UART_BAUDRATE); // Configure baudrate


#ifdef UART_FIFO_FEATURE_ENA
	// Configure FIFO
	UART_BASE->C2 = 0; // Disable RX and TX

	UART_BASE->TWFIFO = 0; /* Set tx/rx FIFO watermark */
	UART_BASE->RWFIFO = UART_RX_FIFO_SIZE-1;
	UART_BASE->PFIFO |= UART_PFIFO_TXFE_MASK | UART_PFIFO_RXFE_MASK; /* Enable TX/RX FIFO */
	UART_BASE->CFIFO = UART_CFIFO_TXFLUSH_MASK | UART_CFIFO_RXFLUSH_MASK; /* Flush FIFO */
#endif // UART_FIFO_FEATURE_ENA

	UART_BASE->C2 = UART_C2_TE_MASK | UART_C2_RE_MASK | UART_C2_RIE_MASK; // Enable RX, TX and RX IRQ
}


// UART RX QUEUED

uint8_t UART_IsRxMsg(void)
{
#ifdef UART_FIFO_FEATURE_ENA
	return (rx_queue.count > 0) || (UART_BASE->RCFIFO != 0);
#else
	return (rx_queue.count > 0);
#endif // UART_FIFO_FEATURE_ENA
}


uint8_t UART_GetRxMsgLength(void)
{
#ifdef UART_FIFO_FEATURE_ENA
	return rx_queue.count + UART_BASE->RCFIFO;
#else
	return rx_queue.count;
#endif // UART_FIFO_FEATURE_ENA
}


uint8_t UART_ReadMsg(char* msg, uint8_t cant)
{
	uint8_t i, qCant;

	qCant = rx_queue.count;
	if (cant > qCant)
	{
#ifdef UART_FIFO_FEATURE_ENA
		__LDM_DisableInterrupts();
		UART_FlushRxFifoIntoQueue(); // Esto debe ser ATOMIC!!!
		__LDM_EnableInterrupts();

		qCant = rx_queue.count;
		if (cant > qCant)
#endif // UART_FIFO_FEATURE_ENA
		{
			cant = qCant;
		}
	}

	for (i=0 ; i<cant ; ++i)
	{
		msg[i] = rx_queue.buffer[rx_queue.iGet];
		UART_QUEUE_INDEX_INC(rx_queue.iGet, UART_RX_QUEUE_MSK);
	}
	if (cant)
	{
		__LDM_DisableInterrupts();
		rx_queue.count -= cant; // Esto debe ser ATOMIC!!!
		__LDM_EnableInterrupts();
	}

	return cant;
}


uint8_t UART_WriteMsg(const char* msg, uint8_t cant)
{
	uint8_t i, qFree;

	qFree = UART_TX_QUEUE_SIZE - tx_queue.count;

	if (cant > qFree)
	{
		cant = qFree;
	}

	for (i=0 ; i<cant ; ++i)
	{
		tx_queue.buffer[tx_queue.iPut] = msg[i];
		UART_QUEUE_INDEX_INC(tx_queue.iPut, UART_TX_QUEUE_MSK);
	}

	if (cant)
	{
		__LDM_DisableInterrupts();
		tx_queue.count += cant; // Esto debe ser ATOMIC!!!
		__LDM_EnableInterrupts();
	}

	UART_BASE->C2 |= UART_C2_TIE_MASK; // Enable TDRE IRQ

	return cant;
}


uint8_t UART_IsTxMsgComplete(void)
{
#ifdef UART_FIFO_FEATURE_ENA
	return (tx_queue.count == 0) && (UART_BASE->TCFIFO == 0) && (UART_BASE->S1 & UART_S1_TC_MASK);
#else
	return (tx_queue.count == 0) && (UART_BASE->S1 & UART_S1_TC_MASK);
#endif // UART_FIFO_FEATURE_ENA
}


/*******************************************************************************
 *******************************************************************************
                        LOCAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/


static void UART_SetBaudRate (UART_Type *uart, uint32_t baudrate)
{
	uint16_t sbr, brfa;
	uint32_t clock;

	clock = ((uart == UART0) || (uart == UART1))?(__CORE_CLOCK__):(__CORE_CLOCK__ >> 1);

	baudrate = ((baudrate == 0)?(UART_HAL_DEFAULT_BAUDRATE):
			((baudrate > 0x1FFF)?(UART_HAL_DEFAULT_BAUDRATE):(baudrate)));

	sbr = clock / (baudrate << 4);               // sbr = clock/(Baudrate x 16)
	brfa = (clock << 1) / baudrate - (sbr << 5); // brfa = 2*Clock/baudrate - 32*sbr

	uart->BDH = UART_BDH_SBR(sbr >> 8);
	uart->BDL = UART_BDL_SBR(sbr);
	uart->C4 = (uart->C4 & ~UART_C4_BRFA_MASK) | UART_C4_BRFA(brfa);
}

#if UART_NUM == 0
__ISR__ UART0_RX_TX_IRQHandler (void)
#elif UART_NUM == 3
__ISR__ UART3_RX_TX_IRQHandler (void)
#endif // UART_NUM == xx
{
	uint8_t s1 = UART_BASE->S1;
	if (s1 & UART_S1_RDRF_MASK) // RX IRQ
	{
#ifdef UART_FIFO_FEATURE_ENA
		UART_FlushRxFifoIntoQueue();
#else
		uint8_t rx_data = UART_BASE->D;
		if (rx_queue.count < UART_RX_QUEUE_SIZE)
		{
			++(rx_queue.count);
			rx_queue.buffer[rx_queue.iPut] = rx_data;
			UART_QUEUE_INDEX_INC(rx_queue.iPut, UART_RX_QUEUE_MSK);
		}
#endif // UART_FIFO_FEATURE_ENA
	}
	else // if (s1 & UART_S1_TDRE_MASK) // TX IRQ
	{
#ifdef UART_FIFO_FEATURE_ENA
		UART_FlushTxQueueIntoFifo();
#else
		uint8_t tx_data = tx_queue.buffer[tx_queue.iGet];
		uint8_t dummy_read = UART_BASE->S1;
		UART_BASE->D = tx_data;
		UART_QUEUE_INDEX_INC(tx_queue.iGet, UART_TX_QUEUE_MSK);
		if (!(--(tx_queue.count)))
		{
			UART_BASE->C2 &= ~UART_C2_TIE_MASK; // Disable TDRE IRQ
		}
#endif // UART_FIFO_FEATURE_ENA
	}
}


#ifdef UART_FIFO_FEATURE_ENA
static void UART_FlushRxFifoIntoQueue(void)
{
	uint8_t dummy_read, rx_data;

	while (UART_BASE->RCFIFO)
	{
		dummy_read = UART_BASE->S1;
		rx_data = UART_BASE->D;
		if (rx_queue.count < UART_RX_QUEUE_SIZE)
		{
			++(rx_queue.count);
			rx_queue.buffer[rx_queue.iPut] = rx_data;
			UART_QUEUE_INDEX_INC(rx_queue.iPut, UART_RX_QUEUE_MSK);
		}
	}
}


static void UART_FlushTxQueueIntoFifo(void)
{
	uint8_t dummy_read, tx_data;

	while ((tx_queue.count > 0) && (UART_BASE->TCFIFO < UART_TX_FIFO_SIZE))
	{
		tx_data = tx_queue.buffer[tx_queue.iGet];
		dummy_read = UART_BASE->S1;
		UART_BASE->D = tx_data;
		UART_QUEUE_INDEX_INC(tx_queue.iGet, UART_TX_QUEUE_MSK);
		--(tx_queue.count);
	}
	if (!tx_queue.count)
	{
		UART_BASE->C2 &= ~UART_C2_TIE_MASK; // Disable TDRE IRQ
	}
}
#endif // UART_FIFO_FEATURE_ENA


void UART_Putchar(char tx_data)
{
	do {} while(((UART0->S1)& UART_S1_TDRE_MASK) == 0);

	UART_BASE->D = tx_data;
}


